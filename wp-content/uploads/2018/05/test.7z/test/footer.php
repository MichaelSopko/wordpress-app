<footer class="third-bg">
    <div class="container">
        <div class="row">
            <div class="col-md-12">

                <div class="footer_top">
                    <h4> Share Your Favorite Mobile Apps With Your Friends  </h4>

                    <ul>
                        <li> <a href="http://facebook.com/"> <i class="fa fa-facebook" aria-hidden="true"></i> </a> </li>
                        <li> <a href="http://twitter.com/"> <i class="fa fa-twitter" aria-hidden="true"></i> </a> </li>
                        <li> <a href="http://linkedin.com/"> <i class="fa fa-linkedin" aria-hidden="true"></i> </a> </li>
                        <li> <a href="http://google.com/"> <i class="fa fa-google-plus" aria-hidden="true"></i> </a> </li>
                        <li> <a href="http://youtu.be/"> <i class="fa fa-youtube-square" aria-hidden="true"></i> </a> </li>
                        <li> <a href="https://www.instagram.com"> <i class="fa fa-instagram" aria-hidden="true"></i> </a> </li>
                    </ul>
                </div>




            </div>
        </div>
    </div>

    <div class="footer_bottom fourth-bg">
        <!-- Keep Footer Credit Links Intact -->
        <p> 2016 &copy; Copyright Applayers. All rights Reserved. Powered By Free <a href="http://www.pfind.com/goodies/applayers/">AppLayers</a> Template from <a href="http://www.pfind.com/goodies/">pFind Goodies</a>. </p>
    </div>

</footer>


</body>
<?php wp_footer(); ?>
<!-- JS Plugins -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/css3-animate-it.js"></script>
<script src="http://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.3/jquery.easing.min.js"></script>
<script src="js/agency.js"></script>
</html>
