<aside class="col-md-4">
    <div class="side_blog_bg">

        <div class="news_sletter">
            <div class="side_bar_sub_heading">
                <h6> Newsletter </h6>
            </div>

            <p> Subscribe to our email newsletter for useful tips and resources.</p>

            <form>
                <div class="form-group blog_form">
                    <input type="email" class="form-control" id="exampleInputEmail1" placeholder="Email Address" >
                </div>

                <div class="search_btn-3">
                    <button class="btn btn-default" type="submit">  Subscribe </button>
                </div>
            </form>

        </div>


        <div class="sidebar_wrap">
            <div class="side_bar_heading">
                <h6>Recent POst </h6>
            </div>

            <div class="recent-detail">
                <div class="recent-image">
                    <a href="#"> <img src="images/recent_img1.png" alt="image"> </a>
                </div>

                <div class="recent-text">
                    <h6> <a href="#"> It is a long established fact that a reader </a> </h6>

                    <div class="blog_category side_category">
                        <ul>
                            <li> <a href="#">Company news, </a> </li>
                            <li> <a href="#">Fresh releases </a> </li>
                        </ul>
                    </div>

                </div>
            </div>

            <div class="recent-detail">
                <div class="recent-image">
                    <a href="#"> <img src="images/recent_img2.png" alt="image"> </a>
                </div>

                <div class="recent-text">
                    <h6> <a href="#"> All the Lorem Ipsum generators on the Internet </a> </h6>

                    <div class="blog_category side_category">
                        <ul>
                            <li> <a href="#">Fresh releases  </a> </li>
                        </ul>
                    </div>

                </div>
            </div>

            <div class="recent-detail">
                <div class="recent-image">
                    <a href="#"> <img src="images/recent_img3.png" alt="image"> </a>
                </div>

                <div class="recent-text">
                    <h6> <a href="#"> There are many variations of passages. </a> </h6>

                    <div class="blog_category side_category">
                        <ul>
                            <li> <a href="#">Company news </a> </li>
                        </ul>
                    </div>

                </div>
            </div>

            <div class="recent-detail">
                <div class="recent-image">
                    <a href="#"> <img src="images/recent_img4.png" alt="image"> </a>
                </div>

                <div class="recent-text">
                    <h6> <a href="#"> There are many variations of passages. </a> </h6>

                    <div class="blog_category side_category">
                        <ul>
                            <li> <a href="#">Company news </a> </li>
                        </ul>
                    </div>

                </div>
            </div>

        </div>


        <div class="sidebar_wrap">
            <div class="side_bar_heading">
                <h6> Categories </h6>
            </div>

            <div class="category-detail">
                <ul>
                    <li> <a href="#"> <i class="fa fa-folder-open-o" aria-hidden="true"></i> Company news <span> 25 </span></a> </li>
                    <li> <a href="#"> <i class="fa fa-folder-open-o" aria-hidden="true"></i>Updates <span> 15 </span> </a> </li>
                    <li> <a href="#"> <i class="fa fa-folder-open-o" aria-hidden="true"></i>  Fresh releases <span> 35 </span> </a> </li>
                    <li> <a href="#"> <i class="fa fa-folder-open-o" aria-hidden="true"></i> Actions & offers <span> 10 </span> </a> </li>
                    <li> <a href="#"> <i class="fa fa-folder-open-o" aria-hidden="true"></i> Travel <span> 18 </span> </a> </li>
                    <li> <a href="#"> <i class="fa fa-folder-open-o" aria-hidden="true"></i> Music <span> 16 </span> </a> </li>
                    <li> <a href="#"> <i class="fa fa-folder-open-o" aria-hidden="true"></i> Food & Drink <span> 25 </span> </a> </li>
                </ul>


            </div>


        </div>


        <div class="sidebar_wrap">
            <div class="side_bar_heading">
                <h6> Explore tags </h6>
            </div>

            <div class="tag-detail">
                <ul>
                    <li> <a href="#">  Company news </a> </li>
                    <li> <a href="#">   Fresh releases  </a> </li>
                    <li> <a href="#"> Updates  </a> </li>
                    <li> <a href="#">  Music  </a> </li>
                    <li> <a href="#">  Travel  </a> </li>
                    <li> <a href="#">  Company news </a> </li>
                    <li> <a href="#">   Fresh releases  </a> </li>
                    <li> <a href="#"> Updates  </a> </li>
                    <li> <a href="#">  Music  </a> </li>
                    <li> <a href="#">  Travel  </a> </li>
                </ul>


            </div>


        </div>



    </div>
</aside>