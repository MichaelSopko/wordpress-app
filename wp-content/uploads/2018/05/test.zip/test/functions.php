<?php
function theme_name_scripts() {

}

add_action('wp_enqueue_scripts', 'theme_name_scripts');